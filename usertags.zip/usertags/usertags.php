<?php
/*
Plugin Name: User Tags
Plugin URI: https://example.com
Description: Adds a custom taxonomy "User Tags" for categorizing users in WordPress.
Version: 1.0
Author: Your Name
Author URI: https://example.com
License: GPL2
*/

if (!defined('ABSPATH')) exit;

// Register User Tags Taxonomy
function register_user_tags_taxonomy() {
    register_taxonomy('user_tags', 'user', array(
        'labels' => array(
            'name' => 'User Tags',
            'singular_name' => 'User Tag',
            'menu_name' => 'User Tags',
        ),
        'public' => true,
        'show_admin_column' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'capabilities' => array(
            'manage_terms' => 'edit_users',
            'edit_terms' => 'edit_users',
            'delete_terms' => 'edit_users',
            'assign_terms' => 'edit_users',
        ),
        'rewrite' => false,
    ));
}
add_action('init', 'register_user_tags_taxonomy');

// Add User Tags Metabox to User Profile
function add_user_tags_meta_box($user) {
    $terms = get_terms(array('taxonomy' => 'user_tags', 'hide_empty' => false));
    $user_terms = wp_get_object_terms($user->ID, 'user_tags', array('fields' => 'ids'));
    ?>
    <h3>User Tags</h3>
    <table class="form-table">
        <tr>
            <th><label for="user_tags">Assign Tags</label></th>
            <td>
                <select name="user_tags[]" multiple="multiple" style="width: 300px;">
                    <?php foreach ($terms as $term): ?>
                        <option value="<?php echo esc_attr($term->term_id); ?>" <?php selected(in_array($term->term_id, $user_terms)); ?>>
                            <?php echo esc_html($term->name); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </td>
        </tr>
    </table>
    <?php
}
add_action('show_user_profile', 'add_user_tags_meta_box');
add_action('edit_user_profile', 'add_user_tags_meta_box');

// Save User Tags
function save_user_tags_meta($user_id) {
    if (!current_user_can('edit_user', $user_id)) return false;
    $tags = isset($_POST['user_tags']) ? array_map('intval', $_POST['user_tags']) : array();
    wp_set_object_terms($user_id, $tags, 'user_tags', false);
}
add_action('personal_options_update', 'save_user_tags_meta');
add_action('edit_user_profile_update', 'save_user_tags_meta');

// Add Filtering Dropdown in Users List
function filter_users_by_tags() {
    $taxonomy = 'user_tags';
    $selected = isset($_GET[$taxonomy]) ? $_GET[$taxonomy] : '';
    $terms = get_terms(array('taxonomy' => $taxonomy, 'hide_empty' => false));
    echo '<select name="user_tags" style="float: right; margin-left: 10px;">
        <option value="">Filter by User Tag</option>';
    foreach ($terms as $term) {
        echo '<option value="' . esc_attr($term->slug) . '" ' . selected($selected, $term->slug, false) . '>' . esc_html($term->name) . '</option>';
    }
    echo '</select>';
}
add_action('restrict_manage_users', 'filter_users_by_tags');

// Modify User Query Based on Selected Tag
function filter_users_by_tags_query($query) {
    global $pagenow;
    if (is_admin() && 'users.php' === $pagenow && !empty($_GET['user_tags'])) {
        $query->query_vars['tax_query'] = array(
            array(
                'taxonomy' => 'user_tags',
                'field' => 'slug',
                'terms' => sanitize_text_field($_GET['user_tags']),
            ),
        );
    }
}
add_action('pre_get_users', 'filter_users_by_tags_query');

// Enqueue Select2 for AJAX Search
function enqueue_select2_script($hook) {
    if ('users.php' !== $hook && 'user-edit.php' !== $hook && 'profile.php' !== $hook) return;
    wp_enqueue_script('select2-js', 'https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js', array('jquery'), '4.0.13', true);
    wp_enqueue_style('select2-css', 'https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css', array(), '4.0.13');
    wp_enqueue_script('custom-select2', plugin_dir_url(__FILE__) . 'custom-select2.js', array('jquery', 'select2-js'), '1.0', true);
}
add_action('admin_enqueue_scripts', 'enqueue_select2_script');

// AJAX Handler for User Tags Search
function ajax_user_tags_search() {
    $search_term = isset($_GET['q']) ? sanitize_text_field($_GET['q']) : '';
    $terms = get_terms(array(
        'taxonomy' => 'user_tags',
        'hide_empty' => false,
        'search' => $search_term,
    ));
    $results = array();
    foreach ($terms as $term) {
        $results[] = array('id' => $term->term_id, 'text' => $term->name);
    }
    wp_send_json($results);
}
add_action('wp_ajax_user_tags_search', 'ajax_user_tags_search');

// JavaScript File (custom-select2.js)
function create_custom_select2_script() {
    ?>
    <script>
        jQuery(document).ready(function ($) {
            $('select[name="user_tags[]"]').select2({
                ajax: {
                    url: ajaxurl + '?action=user_tags_search',
                    dataType: 'json',
                    delay: 250,
                    processResults: function (data) {
                        return { results: data };
                    },
                },
                minimumInputLength: 1,
                allowClear: true,
            });
        });
    </script>
    <?php
}
add_action('admin_footer', 'create_custom_select2_script');


// Add "User Tags" to the Users Menu
function add_user_tags_menu() {
    add_users_page(
        'User Tags',   // Page Title
        'User Tags',   // Menu Title
        'edit_users',  // Capability
        'edit-tags.php?taxonomy=user_tags' // Menu Slug
    );
}
add_action('admin_menu', 'add_user_tags_menu');


